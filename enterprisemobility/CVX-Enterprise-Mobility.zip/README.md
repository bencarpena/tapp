# Enterprise Mobility

> - To engage the central Mobile apps team, please feel free to send a request via [go.chevron.com/MobileAppsRequest](go.chevron.com/MobileAppsRequest)
> - To setup your MFA, go to https://go.chevron.com/SetupMFA


## Prologue

### It is not the device that is mobile, it’s us.
Enterprise Mobility is a key driver for change and innovation in our industry.

Mobile Application Management (MAM) is a critical platform capability that helps us provide meaningful and familiar mobile user experiences while ensuring security of the apps & data served by them. It is an essential component of our defense in depth strategy for Mobility and Zero Trust.

By doing so we are REINVENTING productivity and business processes.

All these are predicated on four principles : **Collaboration, Mobility, Intelligence** and **Trust**

- People need to be empowered to be productive. We provide tools and apps that they could collaborate on.
- We will aim for everyone to be productive on any device (and based on our customer focus group discussions - those are both managed and unmanaged devices running on Windows, Mac, Android and iOS) - because it’s not the device that’s mobile, it’s us. 
- To produce meaningful insights and smart analytics, our data pipelines need to be fed with data coming from the solutions and apps we just deployed.
- And to top it all off, we would ensure that only authenticated and authorized users will have the necessary access. Security and Compliance is the tip of the spear of our defense in depth strategy.









