# What is MAM?
><span style="color: #D3D3D3;"> Release notes:</span>
The MAM concepts here apply to Android and iOS only. This wiki now comes with a brief history and advantages to adopting MAM plus infographics and user experience snapshots.



## Overview

## It is not the device that is mobile, it’s us.


Enterprise Mobility is a key driver for change and innovation in our industry.

There is a need to deploy mobile applications to devices of our end users - be it personal (Bring Your Own Device; more aptly called BYOD) or company-issued devices.

In these unprecedented times, working from anywhere means having access to apps that enable you to be more productive and empowered in mobile devices of your choice.

To sum it up, Microsoft's CEO Satya Nadella eloquently describes the anchor strategy for all these in his book, Hit Refresh:

#### "We needed to envision a world where the mobility of the human experience across all devices was what mattered."




## Enter Mobile Application Management

Introduced in early 2018 in Chevron by the Technology, Strategy and Services org and piloted by ITSD's Software Engineering Services Mobile Apps Team, Mobile Application Management (or MAM) along with the enablement of Multi-Factor Authentication (MFA) addresses our digital imperative to securely design, develop, deploy and manage mobile applications to all devices - even those we do not fully own or control.

MAM allows us to manage and secure our applications including the data served by our apps **more granularly** than managing the entire mobile device while preserving the expected and **meaningful user experiences**.

Some of the advantages of implementing a comprehensive enterprise MAM strategy include:

1. application management and governance
1. application discovery and distribution
1. application support and management
1. application protection

## MAM Infographics
![MAM and MDM](https://docs.microsoft.com/en-us/mem/intune/fundamentals/media/byod-technology-decisions/byod-app-device-mgmt.png)

*Credit : Microsoft documentations. See Further reads below.

![CVX MAM](/.attachments/01-cvxmam.png)

## MAM in action on an unmanaged device

 
### MAM and a Jailbroken iOS

See [video](https://web.microsoftstream.com/video/e19cadeb-b69b-4f9a-bc0c-6d39db89f827) of apps that are MAM-enabled using Intune (applied on Microsoft Teams) and Apperian (applied on Field Workflow Enablement's Inspections app).
Additional [video](https://web.microsoftstream.com/video/5218a35b-82de-47e5-89e4-53412c240771) of MAM policies in action on unmanaged devices whereby blocking of jailbroken devices, unsupported iOS device model and a device manufacturer enforcement on Android is done.

Photos for further clarity on the user experience:


[![jailbreak1](/.attachments/02-jailbreak.jpeg)
![jailbreak2](/.attachments/03-jailbreak.png)
![MAM detect jailbreak](/.attachments/04-mamdetectjail.jpeg)
![MAM detect jail 2](/.attachments/05-mamdetectjail.jpeg)]()

### MAM and mobile Operating Systems

See pictures below of MAM policies for both unmanaged Android and iOS requiring that a device be at a certain OS version prior to application launch.

Configurations are specified at Intune.

![MAM OS Detect Android](/.attachments/06-mamosdetect.jpeg)
![MAM OS Detect iOS](/.attachments/07-mamosdetect.png)

### Further reads
1. MAM basics : [https://docs.microsoft.com/en-us/mem/intune/apps/app-management](https://docs.microsoft.com/en-us/mem/intune/apps/app-management)
2. MAM and MDM Decisions : [https://docs.microsoft.com/en-us/mem/intune/fundamentals/byod-technology-decisions](https://docs.microsoft.com/en-us/mem/intune/fundamentals/byod-technology-decisions)
3. MAM FAQ : [https://docs.microsoft.com/en-us/mem/intune/apps/mam-faq](https://docs.microsoft.com/en-us/mem/intune/apps/mam-faq)
4. App Protection Policies : [https://docs.microsoft.com/en-us/mem/intune/apps/app-protection-policy](https://docs.microsoft.com/en-us/mem/intune/apps/app-protection-policy)
