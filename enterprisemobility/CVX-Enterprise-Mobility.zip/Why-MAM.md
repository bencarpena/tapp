# Why MAM?

><span style="color: #D3D3D3;"> Release notes:</span> MAM Dimensions and Features included for additional clarity

### This is why
The simplest context to this would be to granulary manage and secure mobile applications.

> NOTE: 
> It is highly recommended that you MAM-enable your mobile apps that serve sensitive personal and business data including confidential info. 

Having the necessary event triggers and security layers against **jailbroken and rooted devices** are distinct advantages and operational necessities.

Not all applications need to be MAM-enabled though. An example would be apps that serve public-facing info or brochure-type apps.

Our MAM strategies and policies come with these dimensions which is not always present in a managed mobile device:

### Essential MAM Dimensions

<table>
  <tbody>
    <tr>
      <th>Dimensions</th>
      <th>MAM features</th>
    </tr>
    <tr>
      <td>Conditional Launch</td>
      <td>
        <ul>
          <li>Requiring that your mobile device is not jailbroken (iOS) or rooted (Android) prior to app usage</li>
          <li>Requiring that your mobile device is at a certain operating system version prior to app usage</li>
         <li>Requiring that your mobile app does not run on certain mobile devices based on device manufacturer or model</li>
<li>Performing runtime integrity check on the app prior to launch</li>
<li>Enable self-updating app</li>
        </ul>
     </td>
    </tr>
    <tr>
      <td>Data Protection</td>
      <td>
      <ul>
      <li>Ability to remotely wipe in-app preferences and/or data in the app</li>
      <li>Copy Paste Prevention</li>
<li>Download File Prevention</li>
      </ul>
     </td>
    </tr>
    <tr>
      <td>Enforcing custom app access requirements</td>
      <td>
     <ul>
     <li>Set application expiry</li>
     <li>Require PIN before accessing the app</li>
     <li>Require users to accept terms & conditions prior to app usage</li>
     </ul>
   </td>
    </tr>
    <tr>
      <td>
        Gathering application insights & telemetry
      </td>
      <td>
      <ul>
          <li>Gather app usage</li>
          <li>Collect app crash reports</li>
        </ul>
     </td>
    </tr>
  </tbody>
</table>


