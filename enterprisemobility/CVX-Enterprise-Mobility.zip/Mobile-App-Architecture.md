# Mobile App Architecture

## What is Application Architecture?

It is the combination of techniques, patterns and designs for building a structured app ecosystem that provides a
common framework with standards and key principles.

Most common apps (including mobile) consist of a multi-layered design:

- **Presentation Layer** – This represents the UI components, navigation and interactions from the user.
- **Business Layer** – This represents caching, logging, authentication and other business-specific components.
- **Data Layer** – This represents service components associated with securely accessing data.

![Layered Design](/.attachments/Layered_Design.png)

For mobile, we need to consider additional elements:

- **Platform** – Device types used to access the app.
- **UI/UX** – Specific design patterns and navigation based on device features.
- **Process flow** – How and when to pull data (real-time/cache/notifications) with scalability in mind.
- **Bandwidth** – Developing for the possibilities of low or no internet connectivity (offline).

![Mobile Design](/.attachments/Mobile_Design.png)


## Key Principles

A good mobile app architecture follows a set of key principles that enforce good programming practices and patterns.
By following these principles, it enables you to speed up the development lifecycle, take on complicated business logic,
while making maintenance of your app much easier.

### Scalability

As usability increases with our products, our design must be able to handle the demand of additional users and the data
requests associated with the increase load. It should also allow developers to maintain the app (add new features)
without creating bottlenecks or compromised functionality.

### Maintainability

As technology evolves, so does our need for updated or new functionality. Following a well-designed mobile
architecture will reduce the efforts needed to keep your system up and running during these periods of maintenance.

### Reusability

For a faster mobile development lifecycle, it is important that common functionality is designed and developed as
reusable components for any application. This will help encapsulate business protocols, and provide the additional
benefit of stability – which leads to confidence in your application.


### Security

Data security is the most critical, non-functional requirement for any application. Therefore, it is essential to be in sync
with the organization’s security ecosystem, and follow the guidelines outlined for accessing and storing data.

### Performance

User expectations for any type of application are the same: fast and issue free. The more time it takes to process a
request, or if unexpected results are encountered, adoption of your application could be challenging. Choosing the
proper design, leveraging common (proven) components, and scaling back on unnecessary features could minimize
performance risks.

## Chevron Mobility

As Chevron continues to transform its IT, the demand for mobile apps increases. Structure and guidelines are essential
to providing an environment for delivering well-designed, consistent mobile apps.

### Determining the Device

Although Chevron is Apple centric, many of our partners who work with us may use Android devices while accessing our
products. In cases where we offer a BYOD (Bring Your Own Device) approach to participation, it is important that our
mobile apps work seamlessly across both devices. Therefore, it is essential to include in our Mobile Architecture Design
both platforms for any of our products. This will be a key factor when determining our development frameworks.

### Choosing a Development Framework

Each platform – iOS and Android – provide common functionality and device features. However, developing an app that
uses these features on each device can and may be completely different. The following guidelines were established to
include the Key Principles of scalability, maintainability and reusability across both devices.

For NPM-like packages that include common functionality for both devices:

- **Swift/Objective-C** – For iOS-specific features.
- **Kotlin/Java** – For Android-specific features.

NOTE: These languages/frameworks should be limited to packages and device-agnostic components only and not for
app development as a whole.

For app development, cross-platform app frameworks are essential for maintaining a seamless experience for end-users.
It will eliminate the need for two separate code bases per application, as well as create a consistent look-and-feel for our
applications across the enterprise – “develop once, run anywhere”:

- **Xamarin** – An extension to the .NET developer platform with tools and libraries specifically for building apps for
    iOS and Android.
- **React Native** – A framework built on JavaScript that gives a native-like feel to mobile apps.
- **NativeScript** – Using Typescript and Angular, this framework can easily access native iOS and Android APIs
    eliminating the need for any additional knowledge of native development languages.


### Defining the User Interface

Similar to the “Next Page” web application templates, mobile apps will follow the standards outlined by Chevron Brand
as it relates to the styles applied to the UI (e.g., colors, logo placement, etc.). By developing **starter apps** for the
frameworks defined above, the development lifecycle can be reduced and a consistent look-and-feel can be applied that
includes Brand standards.

These starter apps will include the following components (but not limited to):

- **Security** – Multi-factor Authentication and overall app security.
- **Logging** – User activity and access.
- **Caching** – Offline solutions for handling application data.
- **Navigation** – Common methods for user flow.

As new functionality is defined, collaboration will be essential to building out these starter apps (or packages) to include
additional common components.

### Developing a Navigational Flow

Included in the starter apps defined above, there will be several navigational patterns available based on the type of
application that is being developed:

- Single View
- Stacked Navigation Bar
- Tab Controller
- Scroll View
- Search Driven
- Gesture-based

Take special care when choosing a particular flow as it could determine how your users will interact with the features
you are providing. It could also have an impact on how and when data is being pulled from the backend, which could be
affected by the user’s connectivity.

### Dealing with Connectivity

Mobility requires connectivity, which can determine how your application deals with accessing data. When designing
your application, consider incorporating an “offline paradigm” for situations where the user has low-bandwidth or
simply no internet access at all. The starter apps should include the foundation of offline processing, but each app may
need to expand on it, based on its own requirements.

## The Mobile Ecosystem

Mobile apps are not just limited to UI. As outlined above, they are based on a multi-layered design, which includes a
“backend”. This backend could be anything from APIs to a structured/non-structured database.

Since early 2017 , Chevron has engaged with Microsoft to build out the Azure-based cloud platform that we use today.
Along with that comes a number of resources our mobile apps can leverage:

- **Azure Active Directory** – for user authentication.
- **API Management** – for accessing Corporate APIs.
- **SQL Server/Cosmos DB** – for storing/retrieving data.
- **App Center** – for mobile analytics and publishing.

Our mission, as mobile app developers at Chevron, should extend beyond the few apps that we may be responsible for
developing and maintaining. We need to champion this platform by continuing to work with Microsoft to help build out
the mobile capabilities it has to offer. It starts by intra-sourcing common features, knowledge sharing across business
disciplines, and investing in a business culture that encourages collaboration.


