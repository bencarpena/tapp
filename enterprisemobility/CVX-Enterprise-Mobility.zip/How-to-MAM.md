# How to MAM-enable mobile apps?

><span style="color: #D3D3D3;"> Release notes:</span> Contents are customized for Chevron using our existing platform portfolio. Also added more info on Intune SDK


Within Chevron, we have three ways to MAM-enable our mobile apps.

### Platform Engineering Notes 
 <table>
  <tbody>
    <tr>
      <th>Platform</th>
      <th>Overview of Process</th>
    </tr>
    <tr>
      <td>Apperian</td>
      <td>
        <ul>
          <li>Apperian can MAM-enable both iOS and Android apps; no SDK required.</li>
          <li><b>Process 1</b>: Upload apk or ipa file at the platform > select MAM policies to apply</li>
         <li><b>Process 2</b>: Apply MAM policies using the platform APIs and integrating that as part of your CI/CD pipeline </li>
        <li>View Apperian's API documentations <a href='https://help.apperian.com/display/pub/Apperian+API+Reference' target='_blank'>here</a></li>
<li>MAM capabilities of Apperian are found in <a href='https://help.apperian.com/display/pub/Available+Policies' target='_blank'>here</a></li>
        </ul>
     </td>
    </tr>
    <tr>
      <td>Intune</td>
      <td>
      <ul>
      <li>Developers would need to "inject" the Intune SDK in their mobile app</li>
      <li>Process : See more Intune SDK notes <a href='https://dev.azure.com/chevron/CVX-Enterprise-Mobility/_wiki/wikis/CVX-Mobility.wiki/22653/Add-Intune-SDK' target='_blank'>here</a></li>
<li>Users of the apps would need to authenticate in our Azure AD tenant and must have at least an <a href='https://www.microsoft.com/en-us/licensing/product-licensing/enterprise-mobility-security' target='_blank'>EMS E3 license</a> assigned to them</li>
<li>Read baseline requirements for Intune MAM enablement <a href='https://docs.microsoft.com/en-us/mem/intune/apps/mam-faq' target='_blank'>here</a></li>
<li>Why is Intune Company Portal required on Android devices for MAM enforcement? Read <a href=‘ https://docs.microsoft.com/en-us/mem/intune/developer/app-sdk-android’ target=‘_blank’>here</a></li>
<li>More basic info on Intune MAM (app protection policies) are posted <a href='https://docs.microsoft.com/en-us/mem/intune/apps/app-protection-policy' target='_blank'>here</a></li>
      </ul>
     </td>
    </tr>
    <tr>
      <td>Custom Code</td>
      <td>
     <ul>
     <li>Set specific MAM features and dimensions at the code level</li>
     <li>Process differs depending on target mobile operating system, SDKs required and mobile app development platform (e.g. ReactNative, Kotlin, Flutter, Xamarin, etc)</li>
     </ul>
   </td>
    </tr>
  </tbody>
</table>